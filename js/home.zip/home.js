const root = ReactDOM.createRoot(document.getElementById('root'));
const element = 

<div className="box featured-tab">


</div>;
root.render(element);


const availableproduct = ReactDOM.createRoot(document.getElementById('availableproduct'));
const elementavailableproduct =  

<div className="box featured-tab">
   <div className="cat-box">
      <img src="images/pro-image.png" alt="" />
   </div>
   <div className="detail-box featured">
      <h5>KASA SMART WI-FI MULTI COLOUR LED LIGHT STRIP TP-LINK</h5>
   </div>

   

   <div className="prod_btn align-center">

   <div className="avail_products">10 Products Available</div>

      <button className="btn-snowwhite slide">Show Products</button>
   </div>
</div>;
availableproduct.render(elementavailableproduct);


const productbtn = ReactDOM.createRoot(document.getElementById('productbtn'));
const elementproductbtn =  <button className="btn btn-red">See More New Products</button>;
productbtn.render(elementproductbtn);

//ReactDOMClient.createRoot(/*...*/);

const runoutbtn = ReactDOM.createRoot(document.getElementById('runoutbtn'));
const elementrunoutbtn =  <button className="btn btn-blue">See More Run Out Products</button>;
runoutbtn.render(elementrunoutbtn);


// const adbanner = ReactDOM.createRoot(document.getElementById('adbanner'));
// const elementadbanner = <a href="#"><img src="./images/banner_image.png" style="width: 100%;" /></a>;
// adbanner.render(elementadbanner);

// Find all DOM containers, and render products into them.
document.querySelectorAll('.root')
  .forEach(domContainer => {
    // Read the comment ID from a data-* attribute.
    const commentID = parseInt(domContainer.dataset.commentid, 20);
    const root = ReactDOM.createRoot(domContainer);
    root.render(
      (element)
    );
  });

  // Find all DOM containers, and render products into them.
document.querySelectorAll('.availableproduct')
.forEach(domContainer => {
  // Read the comment ID from a data-* attribute.
  const commentID = parseInt(domContainer.dataset.commentid, 10);
  const availableproduct = ReactDOM.createRoot(domContainer);
  availableproduct.render(
    (elementavailableproduct)
  );
});


